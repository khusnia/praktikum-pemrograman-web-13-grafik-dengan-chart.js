<?php
$koneksi = mysqli_connect("localhost", "root", "", "covid");
$USA = mysqli_query($koneksi, "SELECT * FROM tb_covid WHERE nama_negara='USA'");
$Spain = mysqli_query($koneksi, "SELECT * FROM tb_covid WHERE nama_negara='Spain'");
$Italy = mysqli_query($koneksi, "SELECT * FROM tb_covid WHERE nama_negara='Italy'");
$France = mysqli_query($koneksi, "SELECT * FROM tb_covid WHERE nama_negara='France'");
$UK = mysqli_query($koneksi, "SELECT * FROM tb_covid WHERE nama_negara='SUK'");
$Germany = mysqli_query($koneksi, "SELECT * FROM tb_covid WHERE nama_negara='Germany'");
$Turkey = mysqli_query($koneksi, "SELECT * FROM tb_covid WHERE nama_negara='Turkey'");
$Russia = mysqli_query($koneksi, "SELECT * FROM tb_covid WHERE nama_negara='Russia'");
$Iran = mysqli_query($koneksi, "SELECT * FROM tb_covid WHERE nama_negara='Iran'");
$China = mysqli_query($koneksi, "SELECT * FROM tb_covid WHERE nama_negara='China'");
?>

<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Line Chart</title>
    <h3>Line Chart Perbandingan Angka Penderita Covid-19 di 10 Negara</h3>
    <script src="js/Chart.js"></script>
    <style type="text/css">
            .container {
                width: 45%;
                margin: 30px auto;
            }
    </style>
  </head>
  <body>

    <div class="container">
        <canvas id="linechart" width="100" height="100"></canvas>
    </div>

  </body>
</html>

<script  type="text/javascript">
  var ctx = document.getElementById("linechart").getContext("2d");
  var data = {
            labels: ["Total Kasus","Kasus Baru","Total Kematian","Kematian Baru","Total Pulih","Kasus Aktif"],
            datasets: [
                  {
                    label: "USA",
                    fill: false,
                    lineTension: 0.1,
                    backgroundColor: "#29B0D0",
                    borderColor: "#29B0D0",
                    pointHoverBackgroundColor: "#29B0D0",
                    pointHoverBorderColor: "#29B0D0",
                    data: [<?php while ($p = mysqli_fetch_array($USA)) { echo '"' . $p['total_kasus'] . '","' . $p['kasus_baru'] . '","' . $p['total_kematian'] . '","' . $p['kematian_baru'] . '","' . $p['total_pulih'] . '","' . $p['kasus_aktif'] . '",';}?>]
                  },
                  {
                    label: "Spain",
                    fill: false,
                    lineTension: 0.1,
                    backgroundColor: "#2A516E",
                    borderColor: "#2A516E",
                    pointHoverBackgroundColor: "#2A516E",
                    pointHoverBorderColor: "#2A516E",
                    data: [<?php while ($p = mysqli_fetch_array($Spain)) { echo '"' . $p['total_kasus'] . '","' . $p['kasus_baru'] . '","' . $p['total_kematian'] . '","' . $p['kematian_baru'] . '","' . $p['total_pulih'] . '","' . $p['kasus_aktif'] . '",';}?>]
                  },
                  {
                    label: "Italy",
                    fill: false,
                    lineTension: 0.1,
                    backgroundColor: "#F07124",
                    borderColor: "#F07124",
                    pointHoverBackgroundColor: "#F07124",
                    pointHoverBorderColor: "#F07124",
                    data: [<?php while ($p = mysqli_fetch_array($Italy)) { echo '"' . $p['total_kasus'] . '","' . $p['kasus_baru'] . '","' . $p['total_kematian'] . '","' . $p['kematian_baru'] . '","' . $p['total_pulih'] . '","' . $p['kasus_aktif'] . '",';}?>]
                  },
                  {
                    label: "France",
                    fill: false,
                    lineTension: 0.1,
                    backgroundColor: "#CBE0E3",
                    borderColor: "#CBE0E3",
                    pointHoverBackgroundColor: "#CBE0E3",
                    pointHoverBorderColor: "#CBE0E3",
                    data: [<?php while ($p = mysqli_fetch_array($France)) { echo '"' . $p['total_kasus'] . '","' . $p['kasus_baru'] . '","' . $p['total_kematian'] . '","' . $p['kematian_baru'] . '","' . $p['total_pulih'] . '","' . $p['kasus_aktif'] . '",';}?>]
                  },
                  {
                    label: "UK",
                    fill: false,
                    lineTension: 0.1,
                    backgroundColor: "#964B00",
                    borderColor: "#964B00",
                    pointHoverBackgroundColor: "#964B00",
                    pointHoverBorderColor: "#964B00",
                    data: [<?php while ($p = mysqli_fetch_array($UK)) { echo '"' . $p['total_kasus'] . '","' . $p['kasus_baru'] . '","' . $p['total_kematian'] . '","' . $p['kematian_baru'] . '","' . $p['total_pulih'] . '","' . $p['kasus_aktif'] . '",';}?>]
                  },
                  {
                    label: "Germany",
                    fill: false,
                    lineTension: 0.1,
                    backgroundColor: "#00FF00",
                    borderColor: "#00FF00",
                    pointHoverBackgroundColor: "#00FF00",
                    pointHoverBorderColor: "#00FF00",
                    data: [<?php while ($p = mysqli_fetch_array($Germany)) { echo '"' . $p['total_kasus'] . '","' . $p['kasus_baru'] . '","' . $p['total_kematian'] . '","' . $p['kematian_baru'] . '","' . $p['total_pulih'] . '","' . $p['kasus_aktif'] . '",';}?>]
                  },
                  {
                    label: "Turkey",
                    fill: false,
                    lineTension: 0.1,
                    backgroundColor: "#FF00FF",
                    borderColor: "#FF00FF",
                    pointHoverBackgroundColor: "#FF00FF",
                    pointHoverBorderColor: "#FF00FF",
                    data: [<?php while ($p = mysqli_fetch_array($Turkey)) { echo '"' . $p['total_kasus'] . '","' . $p['kasus_baru'] . '","' . $p['total_kematian'] . '","' . $p['kematian_baru'] . '","' . $p['total_pulih'] . '","' . $p['kasus_aktif'] . '",';}?>]
                  },
                  {
                    label: "Russia",
                    fill: false,
                    lineTension: 0.1,
                    backgroundColor: "#6F00FF",
                    borderColor: "#6F00FF",
                    pointHoverBackgroundColor: "#6F00FF",
                    pointHoverBorderColor: "#6F00FF",
                    data: [<?php while ($p = mysqli_fetch_array($Russia)) { echo '"' . $p['total_kasus'] . '","' . $p['kasus_baru'] . '","' . $p['total_kematian'] . '","' . $p['kematian_baru'] . '","' . $p['total_pulih'] . '","' . $p['kasus_aktif'] . '",';}?>]
                  },
                  {
                    label: "Iran",
                    fill: false,
                    lineTension: 0.1,
                    backgroundColor: "#000000",
                    borderColor: "#000000",
                    pointHoverBackgroundColor: "#000000",
                    pointHoverBorderColor: "#000000",
                    data: [<?php while ($p = mysqli_fetch_array($Iran)) { echo '"' . $p['total_kasus'] . '","' . $p['kasus_baru'] . '","' . $p['total_kematian'] . '","' . $p['kematian_baru'] . '","' . $p['total_pulih'] . '","' . $p['kasus_aktif'] . '",';}?>]
                  },
                  {
                    label: "China",
                    fill: false,
                    lineTension: 0.1,
                    backgroundColor: "#808080",
                    borderColor: "#808080",
                    pointHoverBackgroundColor: "#808080",
                    pointHoverBorderColor: "#808080",
                    data: [<?php while ($p = mysqli_fetch_array($China)) { echo '"' . $p['total_kasus'] . '","' . $p['kasus_baru'] . '","' . $p['total_kematian'] . '","' . $p['kematian_baru'] . '","' . $p['total_pulih'] . '","' . $p['kasus_aktif'] . '",';}?>]
                  }
                  ]
          };

  var myLineChart = new Chart(ctx, {
            type: 'line',
            data: data,
            options: {
            legend: {
              display: true
            },
            barValueSpacing: 20,
            scales: {
              yAxes: [{
                  ticks: {
                      min: 0,
                  }
              }],
              xAxes: [{
                          gridLines: {
                              color: "rgba(0, 0, 0, 0)",
                          }
                      }]
              }
          }
        });
</script>