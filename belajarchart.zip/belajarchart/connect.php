<?php 
$host       = "localhost";
$user       = "root";
$password   = "";
$database   = "covid";
$koneksi    = mysqli_connect($host, $user, $password, $database);
?>